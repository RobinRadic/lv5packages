<?php namespace Laradic\Extensions\Events;

abstract class Event {

	//

}
