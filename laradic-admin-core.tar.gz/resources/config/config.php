<?php

return array(
    'paths'                      => array(
        base_path('workbench')
    ),
    'table' => 'extensions',
    'type' => 'laradic-extension'
);
